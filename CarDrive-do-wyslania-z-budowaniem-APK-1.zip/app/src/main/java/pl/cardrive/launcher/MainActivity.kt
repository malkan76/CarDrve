package pl.cardrive.launcher

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(5, 10, 22)
    private val panel = Color.rgb(15, 27, 49)
    private val blue = Color.rgb(0, 145, 255)
    private val white = Color.WHITE
    private val muted = Color.rgb(190, 207, 230)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        buildDashboard()
    }

    private fun buildDashboard() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 8, 14, 8)
            setBackgroundColor(bg)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8, 4, 8, 10)
        }
        header.addView(label("CarDrive", 27f, white, true), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(label(SimpleDateFormat("HH:mm  •  EEEE, d MMM", Locale("pl", "PL")).format(Date()), 17f, muted, true))
        header.addView(label("   LTE  •  NCS", 15f, blue, true))
        root.addView(header)

        val body = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val leftButtons = listOf(
            Triple("🗺  Mapy", "Google Maps", "com.google.android.apps.maps"),
            Triple("🚗  Yanosik", "Nawigacja", "pl.neptis.yanosik.mobi.android"),
            Triple("☎  Telefon", "Połączenia", ""),
            Triple("WhatsApp", "Wiadomości", "com.whatsapp"),
            Triple("♫  Spotify", "Muzyka", "com.spotify.music"),
            Triple("▦  Więcej", "Aplikacje", "")
        )
        leftButtons.forEach { item ->
            left.addView(actionTile(item.first, item.second) {
                when (item.third) {
                    "" -> if (item.first.contains("Telefon")) startActivity(Intent(Intent.ACTION_DIAL))
                         else showApps()
                    else -> launchPackage(item.third)
                }
            }, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        body.addView(left, LinearLayout.LayoutParams(0, -1, 0.22f))

        val mapPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(12, 12, 12, 12)
            setBackgroundColor(Color.rgb(18, 40, 69))
            isClickable = true
            isFocusable = true
            setOnClickListener { launchPackage("pl.neptis.yanosik.mobi.android") }
        }
        mapPanel.addView(label("MAPA • YANOSIK", 23f, white, true))
        mapPanel.addView(label("Dotknij, aby otworzyć nawigację", 15f, muted, false))
        mapPanel.addView(label("➤", 68f, blue, true))
        mapPanel.addView(label("Pełna mapa i prowadzenie uruchamiają się w aplikacji Yanosik", 14f, muted, false))
        val mapLp = LinearLayout.LayoutParams(0, -1, 0.56f).apply {
            setMargins(8, 0, 8, 0)
        }
        body.addView(mapPanel, mapLp)

        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        right.addView(actionTile("♫  Muzyka / Radio FM", "Otwórz odtwarzacz lub tuner", null), LinearLayout.LayoutParams(-1, 0, 1f))
        right.addView(actionTile("☀  Pogoda", "Widżet – do dodania", null), LinearLayout.LayoutParams(-1, 0, 1f))
        body.addView(right, LinearLayout.LayoutParams(0, -1, 0.22f))
        root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))

        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8, 10, 8, 4)
        }
        footer.addView(actionTile("🎙  Mów", "Komendy głosowe", {
            startActivity(Intent(this@MainActivity, VoiceActivity::class.java))
        }), LinearLayout.LayoutParams(0, 64, 1.4f))
        footer.addView(actionTile("⚙  Ustawienia", "CarDrive", { showApps() }), LinearLayout.LayoutParams(0, 64, 1f))
        root.addView(footer)
        setContentView(root)
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8, 5, 8, 5)
        }

    private fun actionTile(title: String, subtitle: String, action: (() -> Unit)?): View =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(10, 8, 8, 8)
            setBackgroundColor(panel)
            addView(label(title, 16f, white, true))
            addView(label(subtitle, 11f, muted, false))
            isClickable = action != null
            isFocusable = action != null
            setOnClickListener { action?.invoke() }
            val p = layoutParams
            if (p is LinearLayout.LayoutParams) {
                p.setMargins(3, 3, 3, 3)
                layoutParams = p
            }
        }

    private fun launchPackage(packageName: String) {
        val intent = packageManager.getLaunchIntentForPackage(packageName)
        if (intent != null) startActivity(intent)
        else Toast.makeText(this, "Nie znaleziono aplikacji. Sprawdź, czy jest zainstalowana.", Toast.LENGTH_LONG).show()
    }

    private fun showApps() {
        Toast.makeText(this, "Dodatkowe aplikacje można uruchomić z listy aplikacji radia.", Toast.LENGTH_LONG).show()
    }
}

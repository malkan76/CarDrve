package pl.cardrive.launcher

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Toast
import java.util.Locale

class VoiceActivity : Activity() {
    private val requestCode = 710

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val speech = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pl-PL")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "pl-PL")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Powiedz polecenie, np. otwórz Yanosik")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        try {
            startActivityForResult(speech, requestCode)
        } catch (_: Exception) {
            Toast.makeText(this, "Brak usługi rozpoznawania mowy. Sprawdź, czy radio ma asystenta lub usługę Google.", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    @Deprecated("Legacy result callback for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == this.requestCode) {
            if (resultCode == RESULT_OK) {
                val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                    ?.firstOrNull()?.lowercase(Locale("pl", "PL")).orEmpty()
                when {
                    "yanosik" in spoken || "janosik" in spoken -> open("pl.neptis.yanosik.mobi.android")
                    "map" in spoken || "nawigac" in spoken -> open("com.google.android.apps.maps")
                    "whatsapp" in spoken || "wiadomo" in spoken -> open("com.whatsapp")
                    "spotify" in spoken || "muzyk" in spoken -> open("com.spotify.music")
                    "telefon" in spoken || "zadzwoń" in spoken || "zadzwon" in spoken ->
                        startActivity(Intent(Intent.ACTION_DIAL))
                    else -> Toast.makeText(this, "Nie rozpoznano polecenia: $spoken", Toast.LENGTH_LONG).show()
                }
            }
            finish()
        }
    }

    private fun open(packageName: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) startActivity(launch)
        else Toast.makeText(this, "Nie znaleziono aplikacji. Sprawdź jej instalację na radiu.", Toast.LENGTH_LONG).show()
    }
}
